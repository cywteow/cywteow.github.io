# Overview

A kodi add-on to watch drama from langlangbay.org

# Installation
1) Download as zip
2) Transfer the zip file into your kodi via file manager/file explorer
3) Open Kodi -> Add-on -> Addon browser -> Install from zip file -> select the zip file you downloaded (Enure your Addon can install from Unknown sources)

# How to see chinese words in kodi
1) Go to Kodi system setting -> Interface -> Skin -> Fonts -> Arial based
