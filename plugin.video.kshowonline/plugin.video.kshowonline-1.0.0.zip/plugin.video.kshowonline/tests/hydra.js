if (top.location != self.location) window.location = "https://unreshiramor.com/4/3239564/";
else {
    function p(t) {
        var e = 0;
        return function() {
            return e < t.length ? {
                done: !1,
                value: t[e++]
            } : {
                done: !0
            }
        }
    }

    function t(t) {
        var e = "undefined" != typeof Symbol && Symbol.iterator && t[Symbol.iterator];
        return e ? e.call(t) : {
            next: p(t)
        }
    }

    function u(t) {
        t = ["object" == typeof globalThis && globalThis, t, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var e = 0; e < t.length; ++e) {
            var r = t[e];
            if (r && r.Math == Math) return r
        }
        throw Error("Cannot find global object")
    }
    var v = u(this),
        w = "function" == typeof Object.defineProperties ? Object.defineProperty : function(t, e, r) {
            return t == Array.prototype || t == Object.prototype ? t : (t[e] = r.value, t)
        };

    function x(t, e) {
        if (e) {
            for (var r = v, n = t.split("."), o = 0; o < n.length - 1; o++) {
                var i = n[o];
                i in r || (r[i] = {}), r = r[i]
            }(i = e(o = r[n = n[n.length - 1]])) != o && null != i && w(r, n, {
                configurable: !0,
                writable: !0,
                value: i
            })
        }
    }

    function y(t) {
        return (t = {
            next: t
        })[Symbol.iterator] = function() {
            return this
        }, t
    }

    function z() {
        this.m = !1, this.h = null, this.w = void 0, this.f = 1, this.J = this.P = 0, this.l = null
    }

    function A(t) {
        if (t.m) throw new TypeError("Generator is already running");
        t.m = !0
    }

    function D(t, e, r) {
        return t.f = r, {
            value: e
        }
    }

    function E(t) {
        this.a = new z, this.W = t
    }

    function H(t, e) {
        A(t.a);
        var r = t.a.h;
        return r ? F(t, "return" in r ? r.return : function(t) {
            return {
                value: t,
                done: !0
            }
        }, e, t.a.return) : (t.a.return(e), G(t))
    }

    function F(t, e, r, n) {
        try {
            var o = e.call(t.a.h, r);
            if (!(o instanceof Object)) throw new TypeError("Iterator result " + o + " is not an object");
            if (!o.done) return t.a.m = !1, o;
            var i = o.value
        } catch (e) {
            return t.a.h = null, t.a.v(e), G(t)
        }
        return t.a.h = null, n.call(t.a, i), G(t)
    }

    function G(t) {
        for (; t.a.f;) try {
            var e = t.W(t.a);
            if (e) return t.a.m = !1, {
                value: e.value,
                done: !1
            }
        } catch (e) {
            t.a.w = void 0, t.a.v(e)
        }
        if (t.a.m = !1, t.a.l) {
            if (e = t.a.l, t.a.l = null, e.U) throw e.R;
            return {
                value: e.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    }

    function I(t) {
        this.next = function(e) {
            return t.o(e)
        }, this.throw = function(e) {
            return t.v(e)
        }, this.return = function(e) {
            return H(t, e)
        }, this[Symbol.iterator] = function() {
            return this
        }
    }

    function J(t) {
        function e(e) {
            return t.next(e)
        }

        function r(e) {
            return t.throw(e)
        }
        return new Promise(function(n, o) {
            ! function t(i) {
                i.done ? n(i.value) : Promise.resolve(i.value).then(e, r).then(t, o)
            }(t.next())
        })
    }

    function ADS() {
        this.protocol = "https:", this.G = this.protocol + "//ping.iamcdn.net", this.retry = 3, this.offset = this.L = 0, this.u = this.c = null, this.b = {
            width: "100%",
            height: "100%",
            autostart: !1,
            cast: {
                appid: "00000000"
            }
        };
        var t = L("thumbnail") ? decodeURIComponent(L("thumbnail")) : null;
        t && (this.b.image = t), (t = decodeURIComponent(L("logo"))) && (this.b.logo = {
            file: t,
            link: "#",
            hide: !0,
            margin: "5px",
            position: "top-right"
        }), t = L("sub") ? decodeURIComponent(L("sub")) : "";
        var e = L("sub-lang") ? decodeURIComponent(L("sub-lang")) : "Default",
            r = Number(L("sub-size")) || 0;
        if (t && (this.b.tracks = [{
                file: (-1 < t.indexOf("googleusercontent") ? "" : "https://proxy.iamcdn.net/sub?url=") + encodeURIComponent(t),
                label: e || "Default",
                default: !0
            }]), this.i = "BPQYVqCmy" || null, this.C = L("d") || null, !this.i && !this.C) return document.getElementById("player").innerText = this.i ? "Please add a <strong>?d=google-drive-id</strong> parameter on <strong>the url</strong>" : "Please add a <strong>?v=slug</strong> parameter on <strong>the url</strong>";
        if (r && M()) var n = setInterval(function() {
            if ("undefined" != typeof jwplayer && jwplayer) try {
                jwplayer().setCaptions({
                    fontSize: r || 20
                }), clearInterval(n)
            } catch (t) {}
        }, 500);
        return N(this, !this.i)
    }

    function N(t, e) {
        return e = void 0 !== e && e, new Promise(function(r) {
            var n, o, i, s, u, a, l;
            return J(new I(new E(function(c) {
                switch (c.f) {
                    case 1:
                        return n = e ? "fileId=" + t.C : "slug=" + t.i, t.G += e ? "/guest" : "", D(c, t.request(t.G, "POST", n), 2);
                    case 2:
                        if (!(o = c.w) || !o.status) {
                            var f = document.getElementById("over");
                            return f && f.remove(), document.getElementById("player").innerText = o ? o.msg : "Error request to server", c.return(r(!1))
                        }
                        if (i = null, void 0 !== o.sources && o.sources.length) {
                            if (o.isStream) {
                                function h(t, e) {
                                    var r = document.createElement("meta");
                                    r.name = t, r.content = e, document.getElementsByTagName("head")[0].appendChild(r)
                                }
                                return localStorage.setItem("jwplayer.qualityLabel", "720p"), h("referrer", "unsafe-url"), h("referrer", "no-referrer"), t.b.sources = o.sources.length ? o.sources : [o.sources], c.return(r(O(t, !1)))
                            }
                            i = o.sources
                        }
                        if (o.url && !/^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+$/.test(o.url) && (s = o.url.split(""), u = JSON.parse(JSON.stringify(s)), s.map(function(t, e) {
                                e == s.length - 1 ? u[0] = t : u[e + 1] = t
                            }), o.url = isCf ? "hydrax.monster" : atob(u.join(""))), t.c = o.url, t.u = (e ? t.C : t.i) + "." + t.c, !o.isHls) {
                            c.f = 3;
                            break
                        }
                        return t.b.file = "https://hydrax.monster/" + t.i + ".m3u8", t.b.type = "hls", D(c, P(), 4);
                    case 4:
                        return p2pml && p2pml.core.HybridLoader.isSupported() ? c.return(r(Q(t))) : c.return(r(O(t, !1)));
                    case 3:
                        if (o.isCdn && window.MediaSource) return c.return(R(t, o.isWs || !1));
                        if (i) {
                            c.f = 5;
                            break
                        }
                        return a = t.request(t.protocol + "//" + t.c, "POST", n), D(c, S(t.protocol + "//" + t.c + "/ping.gif"), 6);
                    case 6:
                        return D(c, a, 7);
                    case 7:
                        if (!(a = c.w) || !a.status || void 0 === a.sources) return document.getElementById("player").innerText = a ? "We're processing this video. Please check back later" : "Error loading media: Unknown network error", c.return(r(!1));
                        i = a.sources;
                    case 5:
                        for (t.b.sources = [], l = 0; l < i.length; l++) "sd" == i[l] ? t.b.sources.push({
                            file: t.protocol + "//" + (M() || isCf ? t.u : t.c) + "#current-browser-timestamp=" + +new Date,
                            label: "360p",
                            default: !0,
                            type: "mp4"
                        }) : "hd" == i[l] ? t.b.sources.push({
                            file: t.protocol + "//www" + (M() || isCf ? t.u : "." + t.c) + "#current-browser-timestamp=" + +new Date,
                            label: "720p",
                            type: "mp4"
                        }) : "fullHd" == i[l] && t.b.sources.push({
                            file: t.protocol + "//whw" + (M() || isCf ? t.u : "." + t.c) + "#current-browser-timestamp=" + +new Date,
                            label: "1080p",
                            type: "mp4"
                        });
                        return c.return(r(O(t)))
                }
            })))
        })
    }

    function R(t, e) {
        e = void 0 !== e && e;
        var r = setInterval(function() {
            "undefined" != typeof SoTrym && SoTrym && (clearInterval(r), window.SoTrymPlayer = SoTrym("player"), window.SoTrymPlayer.setup(Object.assign({
                id: t.i,
                isWs: e,
                domain: t.c
            }, t.b.tracks ? {
                tracks: t.b.tracks
            } : {})))
        }, 500)
    }

    function O(t, e) {
        e = void 0 === e || e;
        var r = setInterval(function() {
            "undefined" != typeof jwplayer && isClick && jwplayer && (clearInterval(r), e && (t.b.events = {
                time: function() {
                    t.L = jwplayer().getPosition()
                },
                play: function() {},
                pause: function() {},
                seek: function(e) {
                    t.offset = e.offset
                },
                error: function(e) {
                    if (t.retry--, !t.retry) return !1;
                    var r = t.L || t.offset || 0,
                        n = jwplayer().getPlaylist();
                    (n = n[0].sources).forEach(function(r, o) {
                        var i = !1,
                            s = !1;
                        switch (r.label) {
                            case "1080p":
                                var u = "#current-browser-timestamp=" + +new Date;
                                s = !0;
                                break;
                            case "720p":
                                u = "#current-browser-timestamp=" + +new Date, i = !0;
                                break;
                            default:
                                u = "#current-browser-timestamp=" + +new Date
                        }
                        n[o].file = t.protocol + "//" + (s ? "whw" : i ? "www" : "") + (224003 == e.code || M() || isCf ? t.u : (i ? "." : "") + t.c) + u
                    }), t.b.sources = n, jwplayer("player").remove(), jwplayer("player").setup(t.b), document.getElementById("over") || (jwplayer("player").seek(r), jwplayer("player").play())
                }
            }), jwplayer("player").setup(t.b))
        }, 500)
    }

    function Q(t) {
        return new Promise(function() {
            var e;
            return J(new I(new E(function(r) {
                return 1 == r.f ? D(r, Promise.all([T("https://iamcdn.net/players/p2p/hls.js"), T("https://iamcdn.net/players/p2p/p2p-media-loader-hlsjs.min.js"), T("https://iamcdn.net/players/p2p/jwplayer.hlsjs.min.js")]), 2) : 3 != r.f ? D(r, r.w, 3) : (e = setInterval(function() {
                    if ("undefined" != typeof jwplayer && jwplayer) {
                        clearInterval(e);
                        var r = jwplayer("player");
                        r.setup({
                            file: t.b.file,
                            width: "100%",
                            height: "100%"
                        }), jwplayer_hls_provider.attach();
                        var n = new p2pml.hlsjs.Engine({});
                        p2pml.hlsjs.initJwPlayer(r, {
                            liveSyncDurationCount: 7,
                            loader: n.createLoaderClass()
                        })
                    }
                }), void(r.f = 0))
            })))
        })
    }

    function S(t) {
        return new Promise(function(t) {
            return t(!0)
        })
    }

    function M() {
        return isCf || navigator.userAgent.match(/iPhone|iPad|iPod|Mac OS|UCBrowser/i)
    }

    function T(t) {
        return new Promise(function(e, r) {
            var n = document.createElement("script");
            n.type = "text/javascript", n.onload = function() {
                e()
            }, n.onerror = function() {
                console.log("Failed to load script", t), r()
            }, n.src = t, document.head.appendChild(n)
        })
    }

    function P() {
        return new Promise(function(t) {
            ! function e() {
                void 0 === window.p2pml || void 0 === window.p2pml.core ? setTimeout(e, 200) : t()
            }()
        })
    }

    function L(t) {
        return (t = new RegExp(t + "\\=([^\\?&]+)", "i")).test(window.location.href) ? (t = t.exec(window.location.href), decodeURIComponent(t[1])) : ""
    }
    x("Promise", function(e) {
        function r(t) {
            this.s = 0, this.F = void 0, this.j = [];
            var e = this.B();
            try {
                t(e.resolve, e.reject)
            } catch (t) {
                e.reject(t)
            }
        }

        function n() {
            this.g = null
        }

        function o(t) {
            return t instanceof r ? t : new r(function(e) {
                e(t)
            })
        }
        if (e) return e;
        n.prototype.H = function(t) {
            if (null == this.g) {
                this.g = [];
                var e = this;
                this.I(function() {
                    e.S()
                })
            }
            this.g.push(t)
        };
        var i = v.setTimeout;
        n.prototype.I = function(t) {
            i(t, 0)
        }, n.prototype.S = function() {
            for (; this.g && this.g.length;) {
                var t = this.g;
                this.g = [];
                for (var e = 0; e < t.length; ++e) {
                    var r = t[e];
                    t[e] = null;
                    try {
                        r()
                    } catch (t) {
                        this.O(t)
                    }
                }
            }
            this.g = null
        }, n.prototype.O = function(t) {
            this.I(function() {
                throw t
            })
        }, r.prototype.B = function() {
            function t(t) {
                return function(n) {
                    r || (r = !0, t.call(e, n))
                }
            }
            var e = this,
                r = !1;
            return {
                resolve: t(this.Y),
                reject: t(this.D)
            }
        }, r.prototype.Y = function(t) {
            if (t === this) this.D(new TypeError("A Promise cannot resolve to itself"));
            else if (t instanceof r) this.Z(t);
            else {
                t: switch (typeof t) {
                    case "object":
                        var e = null != t;
                        break t;
                    case "function":
                        e = !0;
                        break t;
                    default:
                        e = !1
                }
                e ? this.X(t) : this.K(t)
            }
        }, r.prototype.X = function(t) {
            var e = void 0;
            try {
                e = t.then
            } catch (t) {
                return void this.D(t)
            }
            "function" == typeof e ? this.$(e, t) : this.K(t)
        }, r.prototype.D = function(t) {
            this.M(2, t)
        }, r.prototype.K = function(t) {
            this.M(1, t)
        }, r.prototype.M = function(t, e) {
            if (0 != this.s) throw Error("Cannot settle(" + t + ", " + e + "): Promise already settled in state" + this.s);
            this.s = t, this.F = e, this.T()
        }, r.prototype.T = function() {
            if (null != this.j) {
                for (var t = 0; t < this.j.length; ++t) s.H(this.j[t]);
                this.j = null
            }
        };
        var s = new n;
        return r.prototype.Z = function(t) {
            var e = this.B();
            t.A(e.resolve, e.reject)
        }, r.prototype.$ = function(t, e) {
            var r = this.B();
            try {
                t.call(e, r.resolve, r.reject)
            } catch (t) {
                r.reject(t)
            }
        }, r.prototype.then = function(t, e) {
            function n(t, e) {
                return "function" == typeof t ? function(e) {
                    try {
                        o(t(e))
                    } catch (t) {
                        i(t)
                    }
                } : e
            }
            var o, i, s = new r(function(t, e) {
                o = t, i = e
            });
            return this.A(n(t, o), n(e, i)), s
        }, r.prototype.catch = function(t) {
            return this.then(void 0, t)
        }, r.prototype.A = function(t, e) {
            function r() {
                switch (n.s) {
                    case 1:
                        t(n.F);
                        break;
                    case 2:
                        e(n.F);
                        break;
                    default:
                        throw Error("Unexpected state: " + n.s)
                }
            }
            var n = this;
            null == this.j ? s.H(r) : this.j.push(r)
        }, r.resolve = o, r.reject = function(t) {
            return new r(function(e, r) {
                r(t)
            })
        }, r.race = function(e) {
            return new r(function(r, n) {
                for (var i = t(e), s = i.next(); !s.done; s = i.next()) o(s.value).A(r, n)
            })
        }, r.all = function(e) {
            var n = t(e),
                i = n.next();
            return i.done ? o([]) : new r(function(t, e) {
                function r(e) {
                    return function(r) {
                        s[e] = r, 0 == --u && t(s)
                    }
                }
                var s = [],
                    u = 0;
                do {
                    s.push(void 0), u++, o(i.value).A(r(s.length - 1), e), i = n.next()
                } while (!i.done)
            })
        }, r
    }), x("Symbol", function(t) {
        function e(t, e) {
            this.N = t, w(this, "description", {
                configurable: !0,
                writable: !0,
                value: e
            })
        }
        if (t) return t;
        e.prototype.toString = function() {
            return this.N
        };
        var r = 0;
        return function t(n) {
            if (this instanceof t) throw new TypeError("Symbol is not a constructor");
            return new e("jscomp_symbol_" + (n || "") + "_" + r++, n)
        }
    }), x("Symbol.iterator", function(t) {
        if (t) return t;
        t = Symbol("Symbol.iterator");
        for (var e = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), r = 0; r < e.length; r++) {
            var n = v[e[r]];
            "function" == typeof n && "function" != typeof n.prototype[t] && w(n.prototype, t, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return y(p(this))
                }
            })
        }
        return t
    }), z.prototype.o = function(t) {
        this.w = t
    }, z.prototype.v = function(t) {
        this.l = {
            R: t,
            U: !0
        }, this.f = this.P || this.J
    }, z.prototype.return = function(t) {
        this.l = {
            return: t
        }, this.f = this.J
    }, E.prototype.o = function(t) {
        return A(this.a), this.a.h ? F(this, this.a.h.next, t, this.a.o) : (this.a.o(t), G(this))
    }, E.prototype.v = function(t) {
        return A(this.a), this.a.h ? F(this, this.a.h.throw, t, this.a.o) : (this.a.v(t), G(this))
    }, ADS.prototype.request = function(t, e, r, n, o) {
        r = void 0 === r ? null : r, o = void 0 === o ? {} : o;
        var i = {
            method: e = void 0 === e ? "GET" : e,
            credentials: n = void 0 === n ? "same-origin" : n,
            headers: Object.assign(o, {
                "Content-Type": "application/x-www-form-urlencoded"
            })
        };
        r && (i.body = r);
        var s = this;
        return new Promise(function(u) {
            fetch(t, i).then(function(t) {
                return t.json()
            }).then(function(t) {
                return s.retry = 3, t && t.status ? u(t) : u(t || null)
            }).catch(function() {
                if (s.retry--, !s.retry) return u(null);
                setTimeout(function() {
                    return u(s.request(t, e, r, n, o))
                }, 1e3 * s.retry)
            })
        })
    }
}! function(e, t, n, a, i, o, r) {
    e.GoogleAnalyticsObject = "ga", e.ga = e.ga || function() {
        (e.ga.q = e.ga.q || []).push(arguments)
    }, e.ga.l = 1 * new Date, o = t.createElement(n), r = t.getElementsByTagName(n)[0], o.async = 1, o.src = "https://www.google-analytics.com/analytics.js", r.parentNode.insertBefore(o, r)
}(window, document, "script"), ga("create", "UA-151663251-1", "auto"), ga("send", "pageview"); //localStorage.setItem('jwplayer.qualityLabel','360p');
var _0xaed1 = ["getTime", "debugger", "constructor", "href", "location", "https://iamcdn.net/ban.html?v=" + L("v"), "undefined", "remove", "", "write", "clear", "script", "createElement", "textContent", "//# sourceMappingURL=", "appendChild", "head", "(^|[^;]+)\\s*", "\\s*=\\s*([^;]+)", "match", "cookie", "pop", "id", "defineProperty", "https://playhydrax.com/map", "log", "true", "isMap"],
    element = new Image,
    devtoolsOpen = !1;

function _time() {
    var e = (new Date)[_0xaed1[0]]();
    (function() {})[_0xaed1[2]](_0xaed1[1])(), (new Date)[_0xaed1[0]]() - e >= 200 && (_clear(), window[_0xaed1[4]][_0xaed1[3]] = _0xaed1[5])
}

function _clear() {
    try {
        _0xaed1[6] != typeof jwplayer && jwplayer && jwplayer()[_0xaed1[7]](), document[_0xaed1[9]](_0xaed1[8]), console[_0xaed1[10]]()
    } catch (e) {}
}

function smap(e) {
    const a = document[_0xaed1[12]](_0xaed1[11]);
    a[_0xaed1[13]] = `${_0xaed1[14]}${e}${_0xaed1[8]}`, document[_0xaed1[16]][_0xaed1[15]](a), a[_0xaed1[7]]()
    console.log(a)
}

function getCookieValue(e) {
    var a = document[_0xaed1[20]][_0xaed1[19]](_0xaed1[17] + e + _0xaed1[18]);
    return a ? a[_0xaed1[21]]() : _0xaed1[8]
}

Object[_0xaed1[23]](element, _0xaed1[22], {
    get: function() {
        devtoolsOpen = true
    }
}), smap(_0xaed1[24]), (function() {
    devtoolsOpen = false, console[_0xaed1[25]](element), devtoolsOpen ? (console.log("prevent redirect")) : _0xaed1[26] != getCookieValue(_0xaed1[27]) ? (_clear(), window[_0xaed1[4]][_0xaed1[3]] = _0xaed1[5]) : (smap(_0xaed1[24]), _time())
});